<?php

require_once('TitleRequest.php');

$json = $_POST['boddy'];
TitleRequest::update($json);