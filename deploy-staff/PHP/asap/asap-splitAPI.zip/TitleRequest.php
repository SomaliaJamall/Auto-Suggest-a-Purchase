<?php

require_once('DBModel.php');

class TitleRequest extends DBModel {
	public $id;
	public $barcode;
	public $title;
	public $author;
	public $identifier;
	public $format;
	public $publication;
	public $autohold;
	public $status;
	public $created;

	public static function loadTitleRequests($status = null) {
		$mysqli_connection = Self::fetchDBConnection();

		$query = "SELECT * FROM title_requests";
		if(!empty($status)) {
			$query .= " where status=?";
			$statement = $mysqli_connection->prepare($query);
			$statement->bind_param('i', $status);
		}
		else {
			$statement = $mysqli_connection->prepare($query);

		}

		$statement->execute();
		$result = $statement->get_result();
		$rows = $result->fetch_all(MYSQLI_ASSOC);

		$titleRequests = [];
		foreach ($rows as $data) {
			$titleRequests[] = self::createFromData($data);
		}

		return $titleRequests;
	}

	public static function loadTitleRequest($titleRequestId) {
		$mysqli_connection = Self::fetchDBConnection();

		$query = "SELECT * FROM title_requests where id=?";
		$statement = $mysqli_connection->prepare($query);
		$statement->bind_param('i', $titleRequestId);
		
		$statement->execute();
		$result = $statement->get_result();
		$rows = $result->fetch_all(MYSQLI_ASSOC);

		if(!empty($rows)) {
			return Self::createFromData($rows[0]);
		}
	
		return null;
	}

	public static function add($json) {
		$mysqli_connection = Self::fetchDBConnection();

		try {
			$data = json_decode($json, true);
			$barcode = $data['barcode'];
			$title = ucwords($data['title']);
			$author = $data['author'];
			$identifier = $data['isbn'];
			$format = $data['format'];
			$publication = $data['publication'];
			$autohold = !empty($data['autohold']);
			$status = $data['status'];
			$mysqli_connection->begin_transaction();
			// Instert all the new tags for that category.
			$insert_query = "INSERT INTO title_requests (barcode, title, author, identifier, format, publication, autohold, status) VALUES (?,?,?,?,?,?,?,?)";
			$statement = $mysqli_connection->prepare($insert_query);
			$statement->bind_param('ssssssii', $barcode, $title, $author, $identifier, $format, $publication, $autohold, $status);
			$statement->execute();
			$mysqli_connection->commit();
		}
		catch(Exception $e) {
			$mysqli_connection->rollback();
			throw $e;
		}
	}

	public static function update($json) {
		$data = json_decode($json, true);
		$updateFields = [];
		$updateBinding = '';
		$id = $data['id'];

		if(isset($data['barcode'])) {
			$updateFields['barcode'] = $data['barcode'];
			$updateBinding .= 's';
		}

		if(isset($data['title'])) {
			$updateFields['title'] = ucwords($data['title']);
			$updateBinding .= 's';
		}

		if(isset($data['author'])) {
			$updateFields['author'] = $data['author'];
			$updateBinding .= 's';
		}
		
		if(isset($data['isbn'])) {
			$updateFields['identifier'] = $data['isbn'];
			$updateBinding .= 's';
		}
		
		if(isset($data['format'])) {
			$updateFields['format'] = $data['format'];
			$updateBinding .= 's';
		}
		
		if(isset($data['publication'])) {
			$updateFields['publication'] = $data['publication'];
			$updateBinding .= 's';
		}
		
		if(isset($data['autohold'])) {
			$updateFields['autohold'] = !empty($data['autohold']);
			$updateBinding .= 'i';
		}

		if(isset($data['status'])) {
			$updateFields['status'] = $data['status'];
			$updateBinding .= 'i';
		}

		$setClause = implode(" = ?, ", array_keys($updateFields)) . ' = ? ';
		$updateFields['id'] = $id;
		$updateBinding .= 'i';
		$mysqli_connection = Self::fetchDBConnection();
		$mysqli_connection->begin_transaction();
		// Instert all the new tags for that category.
		$query = "UPDATE title_requests SET $setClause WHERE id = ?";
		$statement = $mysqli_connection->prepare($query);
		$statement->bind_param($updateBinding, ...array_values($updateFields));
		$statement->execute();
		$mysqli_connection->commit();
	}

	public function jsonSerialize(): mixed {
		return [
			'id' => $this->id,
			'barcode' => $this->barcode,
			'title' => $this->title,
			'author' => $this->author,
			'identifier' => $this->identifier,
			'format' => $this->format,
			'publication' => $this->publication,
			'autohold' => $this->autohold,
			'status' => $this->status,
			'created' => $this->created,
		];
	}

	protected static function createFromData($data) {
		$tr = new TitleRequest();
		$tr->id = $data['id'];
		$tr->barcode = $data['barcode'];
		$tr->title = $data['title'];
		$tr->author = $data['author'];
		$tr->identifier = $data['identifier'];
		$tr->format = $data['format'];
		$tr->publication = $data['publication'];
		$tr->autohold = $data['autohold'];
		$tr->status = $data['status'];
		$tr->created = $data['created'];
		return $tr;
	}
}