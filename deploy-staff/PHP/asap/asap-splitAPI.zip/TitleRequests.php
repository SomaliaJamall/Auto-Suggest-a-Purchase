<?php

require_once('TitleRequest.php');

$status - null;
if(isset($_GET['status']) && !empty($_GET['status'])) {
	$status = $_GET['status'];
}

$titleRequests = TitleRequest::loadTitleRequests($status);
echo json_encode($titleRequests);